/**
 * 
 */
/**
 * 
 */
module cofrinho {
}