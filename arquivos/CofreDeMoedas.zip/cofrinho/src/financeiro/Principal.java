package financeiro;

import java.util.Scanner;

public class Principal {
	public static void main(String [] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		cofrinho cofre = new cofrinho(); //cria o cofrinho que armazena as moedas
		Moeda moeda = null; //instancia a moeda conforme a escolha do usuário.
		
		int opcao; //guarda a opção do menu principal
		int opcaoMoeda = 0; //guarda a opção do tipo de moeda
		double valor; //valor digitado pelo usuário
		String tipo; //tipo da moeda escolhida
		
		//exibe o menu principal
		cofre.menuCofrinho();
		opcao = teclado.nextInt();
		
		//Executa enquanto a opção não for 0 (sair)
		while (opcao != 0) {
			
			//reiniciando a variável opcaoMoeda
			opcaoMoeda = 0;
			
			switch(opcao) {
			
			//cria o objeto Moeda conforme a escolha
			case 1: //adiciona moeda
				while(opcaoMoeda > 3 || opcaoMoeda == 0) { //força o usuário a escolher um tipo de moeda
					Moeda.menuMoeda();
					opcaoMoeda = teclado.nextInt();
				}
				
				if(opcaoMoeda == 1) {
					
					System.out.println("Digite o valor a ser adicionado: ");
					valor = teclado.nextDouble();
					tipo = "Dolar";
					moeda = new Dolar(valor,tipo);
					
				} else if(opcaoMoeda == 2) {
					System.out.println("Digite o Valor a ser adicionado: ");
					valor = teclado.nextDouble();
					tipo = "Euro";
					moeda = new Euro(valor, tipo);
					
				} else if(opcaoMoeda == 3) {
					System.out.println("Digite o valor a ser adicionado: ");
					valor = teclado.nextDouble();
					tipo = "Real";
					moeda = new Real(valor, tipo);
				}
				
				cofre.adicionar(moeda); //adicionando a moeda ao cofrinho
				
				break;
				
			case 2: //remove a moeda
				
				while(opcaoMoeda > 3 || opcaoMoeda == 0) {
					Moeda.menuMoeda();
					opcaoMoeda = teclado.nextInt();
				}
				
				//cria o objeto correspondente para remover a moeda
				if(opcaoMoeda == 1) {
					System.out.println("Digite o Valor a ser removido");
					valor = teclado.nextDouble();
					tipo = "Dolar";
					moeda = new Dolar(valor, tipo);
					
				} else if(opcaoMoeda == 2) {
					System.out.println("Digite o Valor a ser removido");
					valor = teclado.nextDouble();
					tipo = "Euro";
					moeda = new Euro(valor, tipo);
					
				} else {
					System.out.println("Digite o Valor a ser removido");
					valor = teclado.nextDouble();
					tipo = "Real";
					moeda = new Real(valor, tipo);
				}
				
				cofre.remover(moeda); //remove a moeda 
				break;
			
			case 3: //lista as moedas
				cofre.listar();
				break;
				
			case 4: //exibe o total convertido
				cofre.totalConvertido();
				break;
			default:
				System.out.println("Opção inválida. Tente novamente.");
				break;
			}
			//exibe o menu novamente e lê a nova opção
			cofre.menuCofrinho();
			opcao = teclado.nextInt(); //lendo a opção do usuário.	
		}
		
		System.out.println("Encerrando...");
		teclado.close();
	}
}
