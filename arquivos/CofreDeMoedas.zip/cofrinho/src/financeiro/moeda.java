package financeiro;

import java.util.Objects;

abstract class Moeda {
	protected double valor; //define o valor da moeda(número com casas decimais)
	protected String tipo; //representa o tipo da moeda.
	
	protected Moeda(double valor, String tipo) { //usando o construtor protegido para ser acessado em subclasses 
		this.valor = valor; //atribuição do valor passado ao atributo da instância.
		this.tipo = tipo;
	}

	public double getValor() {
		return valor; // para retornar o valor da moeda.
	}
	
	public void setValor(double valor) {
		this.valor = valor; //recebe e define um novo valor para a moeda.
	}
	
	abstract double converter(); //retornar o valor da moeda convertida. 
	
	public void info() { 
		System.out.println("Moeda: " + tipo); //imprimir as informações da moeda.
		System.out.println("Valor: " + getValor());
	}
	
	public static void menuMoeda() {
		System.out.println("--------------------------------");
		System.out.println(" 1 - Dolar | 2 - Euro | 3 - Real");
		System.out.println("--------------------------------");//menu mostrando os tipos de moedas.
		System.out.println("Digite a moeda:   ");
	}
	
	@Override //indica a sobreescrita de um método da classe Object
	public int hashCode() {
		return Objects.hash(tipo, valor); //gera o hash da moeda baseado em tipo e valor.
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) //se for igual ao parametro retornará verdadeiro.
			return true;
		if(obj == null) //se for nulo retornará falso.
			return false;
		if(getClass() != obj.getClass())
			return false; // se o objeto não for da mesma classe, não são iguais.  
		Moeda other = (Moeda) obj;
		return Objects.equals(tipo, other.tipo) //compara o tipo da moeda e o valor para verificar igualdade.
				&& Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
	}
}
