package financeiro;

public class Dolar extends Moeda { //Dolar é uma subclasse que herda os atributos da classe Moeda.
	
	public Dolar(double valor, String tipo) {
		super(valor, tipo); //chama o construtor da classe mãe
	}
	
	@Override //método de sobreescrita
	double converter() {
		return getValor() * 5.34; //será convertido com base no valor do dolar atual.
	}
	
	@Override
	public String toString() { //retornará uma mensagem de representação do objeto. 
		return "Dolar [converter()=" + converter() + ", valor()" + getValor() + ", getClass()" + getClass() + ", hashCode()" + hashCode() + ",to String()" + super.toString() + "]";
	}
	
	@Override 
	public int hashCode() {
		return super.hashCode(); //usa o hashcode da classe mãe
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) //compara referência
			return true;
		if(!super.equals(obj)) //delega parte da comparação pra classe mãe
			return false;
		if(getClass() != obj.getClass()) //garante que são da mesma classe
			return false;
		return true;
	}
}