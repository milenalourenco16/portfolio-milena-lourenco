package financeiro;

import java.util.ArrayList;

public class cofrinho {
	private ArrayList<Moeda> listaMoedas = new ArrayList<Moeda>(); //lista de moedas
	
	public void adicionar(Moeda m) {
		listaMoedas.add(m);//adiciona a moeda à lista
	}
	
	public void remover(Moeda m) {
		if(listaMoedas.isEmpty()) {
			System.out.println("Sem moedas no cofrinho.");//imprime a mensagem
			return; //retorna caso esteja vazio
		} 
		else {
			listaMoedas.remove(m); //aqui remove a moeda.
		}
	}
	
	public void listar() { //lista moedas no cofrinho
		for (Moeda m: listaMoedas) { //para cada moeda, exibe suas informações usando o método info()
			m.info();
		}
	}
	
	public void totalConvertido() {
		double total = 0;
		for(Moeda moeda : listaMoedas) {//percorre a lista e soma o valor convertido de cada moeda.
			total += moeda.converter();
		}
		System.out.printf("Total em real: R$ %.2f%n", total);
	
		
	}
	
	
	public void menuCofrinho() {
		System.out.println("-----------------------------");
		System.out.println("             Menu            ");
		System.out.println("   1 - Adicionar as Moedas   ");
		System.out.println("   2 - Remover as Moedas     ");
		System.out.println("   3 - Listar as Moedas      ");
		System.out.println("   4 - Mostrar o total em R$ ");
		System.out.println("   0 - sair                  ");
		System.out.println("-----------------------------");
		System.out.println("  Digite a opção desejada:   ");
		System.out.println("-----------------------------"); //menu das moedas.
	}
}
